from datetime import datetime
from pydantic import BaseModel
from typing import Optional
from enum import Enum

class StatusLead(str, Enum):
    novo = "novo"
    contato = "contato"
    interessado = "interessado"
    convertido = "convertido"
    rejeitado = "rejeitado"

class OrigemLead(str, Enum):
    whatsapp_grupo = "WhatsApp Grupo"
    whatsapp_direto = "WhatsApp Direto"
    site = "Site"
    campanha = "Campanha"
    referencia = "Referência"

class Lead(BaseModel):
    id: Optional[int] = None
    nome: str
    telefone: str
    origem: OrigemLead
    grupo: Optional[str] = None
    mensagem: Optional[str] = None
    data_extracao: datetime
    status: StatusLead = StatusLead.novo
    tags: str = ""
    
    class Config:
        use_enum_values = True

class GrupoWhatsApp(BaseModel):
    id: Optional[int] = None
    nome: str
    url_convite: Optional[str] = None
    total_membros: int = 0
    data_adicao: datetime
    ativo: bool = True