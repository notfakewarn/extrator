const API_BASE = "http://localhost:8000";

// State
let leads = [];
let grupos = [];
let currentTab = "extracao";

// DOM Elements
const tabBtns = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");
const btnExtrair = document.getElementById("btnExtrair");
const grupoNomeInput = document.getElementById("grupoNome");
const statusExtracao = document.getElementById("statusExtracao");
const leadsTable = document.getElementById("leadsTable");
const leadsBody = document.getElementById("leadsBody");
const btnExportar = document.getElementById("btnExportar");
const btnRefresh = document.getElementById("btnRefresh");
const gruposList = document.getElementById("gruposList");
const btnAdicionarGrupo = document.getElementById("btnAdicionarGrupo");
const novoGrupoInput = document.getElementById("novoGrupo");

// Event Listeners
tabBtns.forEach(btn => {
    btn.addEventListener("click", mudarTab);
});

btnExtrair.addEventListener("click", iniciarExtracao);
btnExportar.addEventListener("click", exportarCSV);
btnRefresh.addEventListener("click", carregarLeads);
btnAdicionarGrupo.addEventListener("click", adicionarGrupo);

// Inicializar
document.addEventListener("DOMContentLoaded", () => {
    carregarLeads();
    carregarGrupos();
    carregarStats();
    
    // Atualizar cada 10 segundos
    setInterval(carregarLeads, 10000);
    setInterval(carregarStats, 15000);
});

// ==================== TABS ====================

function mudarTab(e) {
    const tabName = e.target.dataset.tab;
    
    tabBtns.forEach(btn => btn.classList.remove("active"));
    tabContents.forEach(content => content.classList.remove("active"));
    
    e.target.classList.add("active");
    document.getElementById(tabName).classList.add("active");
    
    currentTab = tabName;
}

// ==================== LEADS ====================

async function carregarLeads() {
    try {
        const response = await fetch(`${API_BASE}/leads`);
        const data = await response.json();
        leads = data.leads || [];
        
        exibirLeads(leads);
    } catch (error) {
        console.error("Erro ao carregar leads:", error);
        mostrarStatus("Erro ao carregar leads", "error");
    }
}

function exibirLeads(leadsParaExibir) {
    if (leadsParaExibir.length === 0) {
        leadsBody.innerHTML = '<tr><td colspan="7" class="loading">Nenhum lead encontrado</td></tr>';
        return;
    }
    
    leadsBody.innerHTML = leadsParaExibir.map(lead => `
        <tr>
            <td>${lead.id}</td>
            <td>${lead.nome}</td>
            <td>${formatarTelefone(lead.telefone)}</td>
            <td>${lead.origem}</td>
            <td>${lead.grupo || '-'}</td>
            <td><span class="badge">${lead.status}</span></td>
            <td>${new Date(lead.data_extracao).toLocaleDateString('pt-BR')}</td>
        </tr>
    `).join("");
}

async function exportarCSV() {
    try {
        const response = await fetch(`${API_BASE}/export`);
        const blob = await response.blob();
        
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `leads_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        mostrarStatus("✅ CSV exportado com sucesso!", "success");
    } catch (error) {
        console.error("Erro ao exportar:", error);
        mostrarStatus("Erro ao exportar CSV", "error");
    }
}

// ==================== EXTRAÇÃO ====================

async function iniciarExtracao() {
    const grupoNome = grupoNomeInput.value.trim();
    
    if (!grupoNome) {
        alert("Digite o nome do grupo!");
        return;
    }
    
    try {
        mostrarStatus("🔄 Iniciando extração... Abra o WhatsApp no seu navegador!", "info");
        btnExtrair.disabled = true;
        
        const response = await fetch(`${API_BASE}/extrair?grupo_nome=${grupoNome}`, {
            method: "POST"
        });
        
        const data = await response.json();
        
        mostrarStatus(`✅ Extração iniciada para o grupo "${grupoNome}"! Aguarde...`, "success");
        grupoNomeInput.value = "";
        
        // Aguardar um pouco e recarregar
        setTimeout(() => {
            carregarLeads();
            carregarGrupos();
            btnExtrair.disabled = false;
        }, 3000);
        
    } catch (error) {
        console.error("Erro:", error);
        mostrarStatus("Erro ao iniciar extração", "error");
        btnExtrair.disabled = false;
    }
}

// ==================== GRUPOS ====================

async function carregarGrupos() {
    try {
        const response = await fetch(`${API_BASE}/grupos`);
        const data = await response.json();
        grupos = data.grupos || [];
        
        exibirGrupos(grupos);
    } catch (error) {
        console.error("Erro ao carregar grupos:", error);
    }
}

function exibirGrupos(gruposParaExibir) {
    if (gruposParaExibir.length === 0) {
        gruposList.innerHTML = '<p class="loading">Nenhum grupo adicionado ainda</p>';
        return;
    }
    
    gruposList.innerHTML = gruposParaExibir.map(grupo => `
        <div class="grupo-card">
            <div class="grupo-name">${grupo.nome}</div>
            <div class="grupo-count">📊 ${grupo.total_membros} membros</div>
        </div>
    `).join("");
}

async function adicionarGrupo() {
    const novoGrupo = novoGrupoInput.value.trim();
    
    if (!novoGrupo) {
        alert("Digite o nome do grupo!");
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/grupos`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome: novoGrupo })
        });
        
        if (response.ok) {
            novoGrupoInput.value = "";
            carregarGrupos();
            mostrarStatus("✅ Grupo adicionado!", "success");
        }
    } catch (error) {
        console.error("Erro:", error);
        mostrarStatus("Erro ao adicionar grupo", "error");
    }
}

// ==================== ESTATÍSTICAS ====================

async function carregarStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        const stats = await response.json();
        
        document.getElementById("totalLeads").textContent = stats.total_leads;
        document.getElementById("totalGrupos").textContent = stats.total_grupos;
        document.getElementById("convertidos").textContent = stats.convertidos;
        
        // Gráfico por grupo
        const statsDiv = document.getElementById("statsPorGrupo");
        if (Object.keys(stats.por_grupo).length === 0) {
            statsDiv.innerHTML = '<p class="loading">Nenhum dado disponível</p>';
        } else {
            const maxValor = Math.max(...Object.values(stats.por_grupo));
            statsDiv.innerHTML = Object.entries(stats.por_grupo).map(([grupo, count]) => {
                const percentual = (count / maxValor) * 100;
                return `
                    <div class="chart-item">
                        <div class="chart-label">${grupo}</div>
                        <div class="chart-bar" style="width: ${percentual}%">${count}</div>
                    </div>
                `;
            }).join("");
        }
    } catch (error) {
        console.error("Erro ao carregar stats:", error);
    }
}

// ==================== UTILITÁRIOS ====================

function formatarTelefone(telefone) {
    const clean = telefone.replace(/\D/g, "");
    if (clean.length === 11) {
        return `(${clean.slice(0, 2)}) ${clean.slice(2, 7)}-${clean.slice(7)}`;
    }
    return telefone;
}

function mostrarStatus(mensagem, tipo) {
    statusExtracao.textContent = mensagem;
    statusExtracao.className = `status ${tipo}`;
    
    if (tipo !== "hidden") {
        setTimeout(() => {
            statusExtracao.className = "status hidden";
        }, 5000);
    }
}