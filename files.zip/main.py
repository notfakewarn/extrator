from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import csv
import io
from datetime import datetime
from typing import List, Optional

from database import (
    criar_banco, adicionar_lead, obter_todos_leads,
    obter_leads_por_grupo, obter_grupos, adicionar_grupo,
    obter_estatisticas
)
from whatsapp_scraper import criar_scraper
from models import Lead, GrupoWhatsApp

# Inicializar banco
criar_banco()

app = FastAPI(
    title="WhatsApp Lead Extrator",
    description="Sistema para extrair leads do WhatsApp",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ===================== ENDPOINTS =====================

@app.get("/")
def root():
    return {
        "mensagem": "🔥 WhatsApp Lead Extrator API",
        "versao": "1.0.0",
        "endpoints": {
            "leads": "/leads",
            "grupos": "/grupos",
            "extrair": "/extrair",
            "exportar": "/export",
            "stats": "/stats"
        }
    }

# ===================== LEADS =====================

@app.get("/leads")
def obter_leads(grupo: Optional[str] = None):
    """Retorna todos os leads ou filtrado por grupo"""
    try:
        if grupo:
            leads = obter_leads_por_grupo(grupo)
        else:
            leads = obter_todos_leads()
        
        return {"total": len(leads), "leads": leads}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/leads")
def criar_lead(lead: Lead):
    """Adiciona novo lead manualmente"""
    try:
        lead_dict = lead.dict()
        sucesso = adicionar_lead(lead_dict)
        
        if sucesso:
            return {"mensagem": "Lead adicionado com sucesso!", "lead": lead_dict}
        else:
            raise HTTPException(status_code=400, detail="Lead já existe ou erro ao adicionar")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ===================== GRUPOS =====================

@app.get("/grupos")
def listar_grupos():
    """Lista todos os grupos"""
    grupos = obter_grupos()
    return {"total": len(grupos), "grupos": grupos}

@app.post("/grupos")
def adicionar_novo_grupo(grupo: GrupoWhatsApp):
    """Adiciona novo grupo para extração"""
    try:
        sucesso = adicionar_grupo(grupo.nome, grupo.url_convite)
        
        if sucesso:
            return {"mensagem": f"Grupo '{grupo.nome}' adicionado!", "grupo": grupo}
        else:
            raise HTTPException(status_code=400, detail="Erro ao adicionar grupo")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ===================== EXTRAÇÃO =====================

@app.post("/extrair")
def iniciar_extracao(grupo_nome: str, background_tasks: BackgroundTasks):
    """Inicia processo de extração do WhatsApp"""
    try:
        # Adicionar grupo
        adicionar_grupo(grupo_nome)
        
        # Executar em background
        background_tasks.add_task(executar_extracao, grupo_nome)
        
        return {
            "mensagem": "Extração iniciada!",
            "grupo": grupo_nome,
            "status": "processando"
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

def executar_extracao(grupo_nome: str):
    """Executa a extração em background"""
    scraper = criar_scraper()
    
    try:
        scraper.iniciar()
        scraper.acessar_whatsapp()
        
        if scraper.abrir_grupo(grupo_nome):
            # Extrair membros
            membros = scraper.extrair_membros_grupo()
            
            for membro in membros:
                lead_dict = {
                    "nome": membro.get("nome"),
                    "telefone": membro.get("telefone"),
                    "origem": "WhatsApp Grupo",
                    "grupo": grupo_nome,
                    "status": "novo"
                }
                adicionar_lead(lead_dict)
            
            print(f"✅ {len(membros)} leads extraídos do grupo '{grupo_nome}'")
        
    except Exception as e:
        print(f"❌ Erro na extração: {e}")
    
    finally:
        scraper.parar()

# ===================== EXPORT =====================

@app.get("/export")
def exportar_csv(grupo: Optional[str] = None):
    """Exporta leads em CSV"""
    try:
        if grupo:
            leads = obter_leads_por_grupo(grupo)
        else:
            leads = obter_todos_leads()
        
        # Criar CSV
        output = io.StringIO()
        fieldnames = ["ID", "Nome", "Telefone", "Origem", "Grupo", "Status", "Data"]
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        
        writer.writeheader()
        for lead in leads:
            writer.writerow({
                "ID": lead["id"],
                "Nome": lead["nome"],
                "Telefone": lead["telefone"],
                "Origem": lead["origem"],
                "Grupo": lead["grupo"] or "-",
                "Status": lead["status"],
                "Data": lead["data_extracao"]
            })
        
        output.seek(0)
        return StreamingResponse(
            iter([output.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=leads.csv"}
        )
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ===================== ESTATÍSTICAS =====================

@app.get("/stats")
def obter_stats():
    """Retorna estatísticas"""
    return obter_estatisticas()

# ===================== HEALTH CHECK =====================

@app.get("/health")
def health_check():
    return {"status": "✅ API online"}