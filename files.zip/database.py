import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional
import os

DB_PATH = "data/leads.db"

def criar_banco():
    """Cria banco de dados e tabelas"""
    os.makedirs("data", exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Tabela de Grupos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS grupos_whatsapp (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            url_convite TEXT,
            total_membros INTEGER DEFAULT 0,
            data_adicao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ativo BOOLEAN DEFAULT 1
        )
    """)
    
    # Tabela de Leads
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            telefone TEXT UNIQUE,
            origem TEXT DEFAULT 'WhatsApp Grupo',
            grupo TEXT,
            mensagem TEXT,
            data_extracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'novo',
            tags TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Índices para buscas rápidas
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_telefone ON leads(telefone)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_origem ON leads(origem)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_grupo ON leads(grupo)
    """)
    
    conn.commit()
    conn.close()

def adicionar_lead(lead_dict: Dict) -> bool:
    """Adiciona novo lead ao banco"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO leads 
            (nome, telefone, origem, grupo, mensagem, status, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            lead_dict.get("nome"),
            lead_dict.get("telefone"),
            lead_dict.get("origem", "WhatsApp Grupo"),
            lead_dict.get("grupo"),
            lead_dict.get("mensagem"),
            lead_dict.get("status", "novo"),
            lead_dict.get("tags", "")
        ))
        
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        # Lead já existe
        return False
    except Exception as e:
        print(f"Erro ao adicionar lead: {e}")
        return False

def obter_todos_leads() -> List[Dict]:
    """Retorna todos os leads"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM leads ORDER BY data_extracao DESC")
    leads = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return leads

def obter_leads_por_grupo(grupo: str) -> List[Dict]:
    """Retorna leads de um grupo específico"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM leads WHERE grupo = ? ORDER BY data_extracao DESC", (grupo,))
    leads = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return leads

def obter_grupos() -> List[Dict]:
    """Retorna todos os grupos"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM grupos_whatsapp WHERE ativo = 1")
    grupos = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return grupos

def adicionar_grupo(nome: str, url_convite: Optional[str] = None) -> bool:
    """Adiciona novo grupo"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO grupos_whatsapp (nome, url_convite)
            VALUES (?, ?)
        """, (nome, url_convite))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Erro ao adicionar grupo: {e}")
        return False

def obter_estatisticas() -> Dict:
    """Retorna estatísticas dos leads"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) as total FROM leads")
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(DISTINCT grupo) as total FROM leads")
    grupos = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) as total FROM leads WHERE status = 'convertido'")
    convertidos = cursor.fetchone()[0]
    
    cursor.execute("""
        SELECT grupo, COUNT(*) as count FROM leads 
        GROUP BY grupo ORDER BY count DESC
    """)
    por_grupo = {row[0]: row[1] for row in cursor.fetchall()}
    
    conn.close()
    
    return {
        "total_leads": total,
        "total_grupos": grupos,
        "convertidos": convertidos,
        "por_grupo": por_grupo
    }