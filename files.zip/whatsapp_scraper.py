from playwright.sync_api import sync_playwright
import re
import time
from typing import List, Dict
import json

class WhatsAppScraper:
    def __init__(self):
        self.browser = None
        self.page = None
        self.leads_encontrados = []
    
    def iniciar(self):
        """Inicia o navegador"""
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=False)
        self.page = self.browser.new_page()
    
    def parar(self):
        """Fecha o navegador"""
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()
    
    def acessar_whatsapp(self):
        """Acessa WhatsApp Web"""
        print("🔗 Acessando WhatsApp Web...")
        self.page.goto("https://web.whatsapp.com", timeout=60000)
        
        # Aguardar escanear QR code
        print("📱 Escaneie o código QR com seu telefone...")
        self.page.wait_for_selector('[data-testid="chat-list"]', timeout=120000)
        print("✅ Autenticação bem-sucedida!")
    
    def abrir_grupo(self, nome_grupo: str):
        """Abre um grupo específico"""
        print(f"🔍 Procurando grupo: {nome_grupo}")
        
        # Buscar grupo
        search_box = self.page.query_selector('[data-testid="search-input"]')
        if search_box:
            search_box.click()
            search_box.type(nome_grupo)
            self.page.wait_for_timeout(2000)
            
            # Clicar no primeiro resultado
            primeiro_resultado = self.page.query_selector('[data-testid="chat-list"] > div:first-child')
            if primeiro_resultado:
                primeiro_resultado.click()
                print(f"✅ Grupo {nome_grupo} aberto!")
                return True
        
        return False
    
    def extrair_membros_grupo(self) -> List[Dict]:
        """Extrai números de telefone dos membros do grupo"""
        print("👥 Extraindo membros do grupo...")
        
        # Abrir informações do grupo
        info_btn = self.page.query_selector('[data-testid="group-info-icon"]')
        if info_btn:
            info_btn.click()
            self.page.wait_for_timeout(2000)
        
        # Scroll para carregar todos os membros
        for _ in range(10):
            self.page.keyboard.press("End")
            self.page.wait_for_timeout(500)
        
        # Extrair contatos
        contatos = self.page.query_selector_all('[data-testid="participant"]')
        
        membros = []
        for contato in contatos:
            try:
                nome = contato.query_selector('[data-testid="participant-name"]')
                telefone_elem = contato.query_selector('[data-testid="participant-number"]')
                
                if nome and telefone_elem:
                    nome_texto = nome.text_content().strip()
                    telefone = self.extrair_telefone(telefone_elem.text_content())
                    
                    if telefone:
                        membros.append({
                            "nome": nome_texto,
                            "telefone": telefone
                        })
            except:
                continue
        
        print(f"✅ {len(membros)} membros encontrados!")
        return membros
    
    def extrair_telefone(self, texto: str) -> str:
        """Extrai número de telefone do texto"""
        # Remover caracteres especiais
        telefone = re.sub(r'\D', '', texto)
        
        # Validar se parece um número válido (10-15 dígitos)
        if 10 <= len(telefone) <= 15:
            return telefone
        
        return None
    
    def extrair_leads_de_mensagens(self, numero_mensagens: int = 100) -> List[Dict]:
        """Extrai leads das mensagens (números de telefone mencionados)"""
        print(f"💬 Extraindo leads das últimas {numero_mensagens} mensagens...")
        
        leads = []
        
        # Scroll para carregar mensagens
        for _ in range(numero_mensagens // 10):
            self.page.keyboard.press("Home")
            self.page.wait_for_timeout(500)
        
        # Buscar padrões de telefone nas mensagens
        mensagens = self.page.query_selector_all('[data-testid="msg"]')
        
        for msg in mensagens[:numero_mensagens]:
            try:
                texto = msg.text_content()
                
                # Padrões de telefone brasileiros
                telephones = re.findall(r'\(?(\d{2})\)?\s?9?\d{4}-?\d{4}', texto)
                
                for telefone in telephones:
                    leads.append({
                        "telefone": telefone,
                        "mensagem": texto[:100],  # Primeiros 100 chars
                        "fonte": "mensagem"
                    })
            except:
                continue
        
        print(f"✅ {len(leads)} leads extraídos das mensagens!")
        return leads

def criar_scraper():
    """Factory para criar scraper"""
    return WhatsAppScraper()